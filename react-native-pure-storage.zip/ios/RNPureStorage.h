#import <React/RCTBridgeModule.h>

@interface RNPureStorage : NSObject <RCTBridgeModule>

@end 